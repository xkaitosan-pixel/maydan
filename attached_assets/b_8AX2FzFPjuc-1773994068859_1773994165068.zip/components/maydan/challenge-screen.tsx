"use client"

import { useState, useEffect } from "react"
import { Crown, Zap } from "lucide-react"

interface ChallengeScreenProps {
  onComplete: (won: boolean) => void
}

const question = {
  text: "ما هي عاصمة المملكة العربية السعودية؟",
  answers: ["الرياض", "جدة", "مكة المكرمة", "المدينة المنورة"],
  correct: 0,
}

export function ChallengeScreen({ onComplete }: ChallengeScreenProps) {
  const [timeLeft, setTimeLeft] = useState(30)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)

  useEffect(() => {
    if (timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && !showResult) {
      handleAnswer(-1)
    }
  }, [timeLeft, showResult])

  const handleAnswer = (index: number) => {
    if (showResult) return
    setSelectedAnswer(index)
    setShowResult(true)
    
    setTimeout(() => {
      onComplete(index === question.correct)
    }, 2000)
  }

  const progress = (timeLeft / 30) * 100

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-secondary/10 via-background to-background" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl" />
      
      {/* Timer Bar */}
      <div className="relative z-10 w-full mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-muted-foreground text-sm font-medium">الوقت المتبقي</span>
          <span className={`text-2xl font-black ${timeLeft <= 10 ? 'text-red-500' : 'text-primary'}`}>
            {timeLeft.toString().padStart(2, '0')}
          </span>
        </div>
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <div 
            className={`h-full rounded-full transition-all duration-1000 ${
              timeLeft <= 10 
                ? 'bg-gradient-to-l from-red-500 to-red-600' 
                : 'bg-gradient-to-l from-primary to-secondary'
            }`}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Players VS Section */}
      <div className="relative z-10 flex items-center justify-between mb-8">
        {/* Player 1 */}
        <div className="flex flex-col items-center">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-secondary to-accent p-0.5">
              <div className="w-full h-full rounded-full bg-card flex items-center justify-center">
                <span className="text-2xl">👤</span>
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-primary rounded-full flex items-center justify-center border-2 border-background">
              <Crown className="w-3 h-3 text-background" />
            </div>
          </div>
          <p className="mt-2 font-bold text-foreground text-sm">أحمد</p>
          <p className="text-primary text-xs font-semibold">٤٢ نقطة</p>
        </div>

        {/* VS Badge */}
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/40 to-secondary/40 rounded-full blur-xl scale-150" />
          <div className="relative w-20 h-20 bg-gradient-to-br from-primary via-primary/90 to-secondary rounded-full flex items-center justify-center shadow-2xl shadow-primary/50 border-2 border-primary/50">
            <div className="flex flex-col items-center">
              <Zap className="w-6 h-6 text-background fill-background" />
              <span className="text-background font-black text-lg">VS</span>
            </div>
          </div>
        </div>

        {/* Player 2 */}
        <div className="flex flex-col items-center">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 p-0.5">
              <div className="w-full h-full rounded-full bg-card flex items-center justify-center">
                <span className="text-2xl">👤</span>
              </div>
            </div>
            <div className="absolute -bottom-1 -left-1 w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center border-2 border-background">
              <span className="text-xs font-bold text-background">٢</span>
            </div>
          </div>
          <p className="mt-2 font-bold text-foreground text-sm">سارة</p>
          <p className="text-emerald-500 text-xs font-semibold">٣٨ نقطة</p>
        </div>
      </div>

      {/* Question Card */}
      <div className="relative z-10 flex-1 flex flex-col">
        <div className="bg-card/80 backdrop-blur-xl rounded-3xl p-6 border border-border/50 shadow-2xl mb-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-secondary/20 rounded-lg flex items-center justify-center">
              <span className="text-secondary font-bold text-sm">س١</span>
            </div>
            <span className="text-muted-foreground text-sm">معلومات عامة</span>
          </div>
          <h2 className="text-xl font-bold text-foreground leading-relaxed text-center">
            {question.text}
          </h2>
        </div>

        {/* Answer Buttons */}
        <div className="space-y-3">
          {question.answers.map((answer, index) => {
            let buttonStyle = "bg-card/60 border-border/50 hover:border-primary/50 hover:bg-card/80"
            
            if (showResult) {
              if (index === question.correct) {
                buttonStyle = "bg-emerald-500/20 border-emerald-500 text-emerald-500"
              } else if (index === selectedAnswer && index !== question.correct) {
                buttonStyle = "bg-red-500/20 border-red-500 text-red-500"
              }
            } else if (selectedAnswer === index) {
              buttonStyle = "bg-primary/20 border-primary"
            }

            return (
              <button
                key={index}
                onClick={() => handleAnswer(index)}
                disabled={showResult}
                className={`w-full p-4 rounded-2xl border-2 backdrop-blur-xl transition-all duration-300 ${buttonStyle}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                    showResult && index === question.correct
                      ? 'bg-emerald-500 text-background'
                      : showResult && index === selectedAnswer
                        ? 'bg-red-500 text-background'
                        : 'bg-muted text-muted-foreground'
                  }`}>
                    {String.fromCharCode(1632 + index + 1)}
                  </div>
                  <span className={`text-lg font-semibold ${
                    showResult && (index === question.correct || index === selectedAnswer)
                      ? ''
                      : 'text-foreground'
                  }`}>
                    {answer}
                  </span>
                </div>
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
