"use client"

import { Shield, Trophy, Target, Flame, Star, Crown } from "lucide-react"

interface HomeScreenProps {
  onEnterArena: () => void
}

export function HomeScreen({ onEnterArena }: HomeScreenProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center px-6 py-8 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-secondary/20 via-background to-background" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      
      {/* Logo Section */}
      <div className="relative z-10 flex flex-col items-center mt-8">
        <div className="relative">
          <div className="absolute inset-0 bg-primary/30 blur-2xl rounded-full scale-150" />
          <div className="relative w-24 h-24 bg-gradient-to-br from-primary via-primary/80 to-secondary rounded-2xl flex items-center justify-center shadow-2xl shadow-primary/40 border border-primary/50">
            <Shield className="w-14 h-14 text-background" strokeWidth={2.5} />
          </div>
        </div>
        <h1 className="text-5xl font-black mt-6 bg-gradient-to-l from-primary via-primary to-secondary bg-clip-text text-transparent">
          ميدان
        </h1>
        <p className="text-muted-foreground text-lg mt-2 font-medium">من يسيطر على الميدان؟</p>
      </div>

      {/* User Profile Card */}
      <div className="relative z-10 w-full max-w-sm mt-10">
        <div className="bg-card/60 backdrop-blur-xl rounded-3xl p-6 border border-border/50 shadow-2xl">
          <div className="flex items-center gap-4">
            {/* Avatar with rank badge */}
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-secondary to-accent p-1">
                <div className="w-full h-full rounded-full bg-card flex items-center justify-center">
                  <span className="text-3xl">👤</span>
                </div>
              </div>
              {/* Rank badge */}
              <div className="absolute -bottom-1 -left-1 w-8 h-8 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center border-2 border-background shadow-lg">
                <Crown className="w-4 h-4 text-background" />
              </div>
            </div>
            
            <div className="flex-1">
              <h2 className="text-xl font-bold text-foreground">أحمد الفارس</h2>
              <div className="flex items-center gap-2 mt-1">
                <Star className="w-4 h-4 text-primary fill-primary" />
                <span className="text-primary font-semibold">المستوى ٧</span>
              </div>
            </div>
          </div>

          {/* Score Display */}
          <div className="flex items-center justify-center gap-8 mt-6">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2">
                <Trophy className="w-6 h-6 text-emerald-500" />
                <span className="text-3xl font-black text-emerald-500">٤٢</span>
              </div>
              <p className="text-muted-foreground text-sm mt-1">انتصارات</p>
            </div>
            
            <div className="w-px h-12 bg-border" />
            
            <div className="text-center">
              <div className="flex items-center justify-center gap-2">
                <Target className="w-6 h-6 text-red-500" />
                <span className="text-3xl font-black text-red-500">١٢</span>
              </div>
              <p className="text-muted-foreground text-sm mt-1">هزائم</p>
            </div>
          </div>
        </div>
      </div>

      {/* Daily Challenges */}
      <div className="relative z-10 w-full max-w-sm mt-6">
        <div className="bg-card/40 backdrop-blur-xl rounded-2xl p-4 border border-border/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-secondary/20 rounded-xl flex items-center justify-center">
                <Flame className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <p className="text-foreground font-semibold">التحديات اليومية</p>
                <p className="text-muted-foreground text-sm">أكمل التحديات للمكافآت</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="w-3 h-3 rounded-full bg-primary shadow-lg shadow-primary/50"
                />
              ))}
            </div>
          </div>
          <p className="text-center text-primary font-bold mt-3">٥/٥ متبقي</p>
        </div>
      </div>

      {/* CTA Button */}
      <div className="relative z-10 w-full max-w-sm mt-auto pb-8">
        <button
          onClick={onEnterArena}
          className="w-full relative group"
        >
          {/* Glow effect */}
          <div className="absolute inset-0 bg-gradient-to-l from-primary via-primary to-secondary rounded-2xl blur-xl opacity-60 group-hover:opacity-80 transition-opacity" />
          
          {/* Button */}
          <div className="relative bg-gradient-to-l from-primary via-primary to-secondary rounded-2xl p-5 flex items-center justify-center gap-3 shadow-2xl shadow-primary/40 border border-primary/50 group-hover:scale-[1.02] transition-transform">
            <span className="text-2xl font-black text-background">ادخل الميدان</span>
            <span className="text-2xl">🔥</span>
          </div>
        </button>
      </div>
    </div>
  )
}
