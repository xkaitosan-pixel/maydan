"use client"

import { useState } from "react"
import { HomeScreen } from "@/components/maydan/home-screen"
import { ChallengeScreen } from "@/components/maydan/challenge-screen"
import { ResultsScreen } from "@/components/maydan/results-screen"

type Screen = "home" | "challenge" | "results"

export default function MaydanApp() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("home")
  const [lastResult, setLastResult] = useState<boolean>(true)

  const handleEnterArena = () => {
    setCurrentScreen("challenge")
  }

  const handleChallengeComplete = (won: boolean) => {
    setLastResult(won)
    setCurrentScreen("results")
  }

  const handlePlayAgain = () => {
    setCurrentScreen("home")
  }

  return (
    <main className="min-h-screen max-w-md mx-auto bg-background relative">
      {/* Mobile frame effect */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 right-0 h-8 bg-gradient-to-b from-black/20 to-transparent" />
      </div>
      
      {currentScreen === "home" && (
        <HomeScreen onEnterArena={handleEnterArena} />
      )}
      
      {currentScreen === "challenge" && (
        <ChallengeScreen onComplete={handleChallengeComplete} />
      )}
      
      {currentScreen === "results" && (
        <ResultsScreen won={lastResult} onPlayAgain={handlePlayAgain} />
      )}
    </main>
  )
}
